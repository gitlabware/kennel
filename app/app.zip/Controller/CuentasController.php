<?php 
class CuentasController extends AppController{
    public $layout = 'kennel';
    public $uses = array('Ingreso','Propietario','Cuentasbancaria', 'Banco', 'Caja', 'Tramite','Tarifa','Examene','Sucursale');
    public function index()
    {
        $cuentas =$this->Cuentasbancaria->find('list',array('fields' => 'Cuentasbancaria.cuenta'));
        $tramites = $this->Tramite->find('list',array('fields' => 'Tramite.nombre'));
        $ingresos = $this->Ingreso->find('all',array('recursive' => 0,'limit' => 50, 'order' => 'Ingreso.id DESC','conditions' => array('Ingreso.sucursale_id' => $this->Session->read('Auth.User.sucursale_id'))));
        //debug($ingresos);exit;
        $this->set(compact('cuentas','tramites','ingresos'));
    }
    public function guardaingreso()
    {
        if(!empty($this->request->data))
        {
            $this->Ingreso->create();
            //$this->request->data['Ingreso']['user_id'] = $this->Session->read('Auth.User.id');
            $sucursal = $this->Session->read('Auth.User.sucursale_id');
            $tramite = $this->request->data['Ingreso']['tramite_id'];
            $idPropietario = $this->request->data['Ingreso']['propietario_id'];
            $propietario = $this->Propietario->findByid($idPropietario,null,null,null,null,-1);
            $this->request->data['Ingreso']['sucursale_id'] = $sucursal;
            $idcuenta = $this->request->data['Ingreso']['cuentasbancaria_id'];
            $cuentasbancaria = $this->Cuentasbancaria->findByid($idcuenta,null,null,null,null,-1);
            if(!empty($cuentasbancaria) && !empty($propietario['Propietario']['tipo_id']))
            {
                $this->request->data['Ingreso']['sucursale_id'] = $cuentasbancaria['Cuentasbancaria']['sucursale_id'];
                $tarifa = $this->Tarifa->find('first',array('recursive' => -1,'conditions' => array('Tarifa.tipo_id' => $propietario['Propietario']['tipo_id'],'Tarifa.sucursale_id' => $cuentasbancaria['Cuentasbancaria']['sucursale_id'],'Tarifa.tramite_id' => $tramite)));
            }
            if(!empty($tarifa))
            {
                $this->request->data['Ingreso']['monto'] = $tarifa['Tarifa']['regional'];
                //$this->request->data['Ingreso']['monto_total'] = $tarifa['Tarifa']['monto_total'];
                $this->request->data['Ingreso']['nacional'] = $tarifa['Tarifa']['nacional'];
                if($this->request->data['Ingreso']['monto_total'] != $tarifa['Tarifa']['monto_total'])
                {
                    $montototal = $this->request->data['Ingreso']['monto_total'];
                    $pornacional = ($tarifa['Tarifa']['nacional']/$tarifa['Tarifa']['monto_total']);
                    $porregional = ($tarifa['Tarifa']['regional']/$tarifa['Tarifa']['monto_total']);
                    $this->request->data['Ingreso']['nacional'] = $pornacional*$montototal;
                    $this->request->data['Ingreso']['monto'] = $porregional*$montototal;
                }
            }
            else{
                $this->Session->setFlash('No se encontro una tarifa para su registro!!!!','msginfo');
                $this->redirect(array('action' => 'index'));
            }
            if($this->Ingreso->save($this->request->data))
            {
                $this->Session->setFlash('Se Registro Correctamente!!!!','msgbueno');
                $this->redirect(array('action' => 'index'));
            }
            else{
                $this->Session->setFlash('No se pudo registrar!!!!','msgerror');
                $this->redirect(array('action' => 'index'));
            }
        }
    }
    public function ajaxpago($idIngreso = null)
    {
        $this->layout = 'ajax';
        $this->Ingreso->id = $idIngreso;
        $this->request->data = $this->Ingreso->read();
        $cuentas =$this->Cuentasbancaria->find('list',array('fields' => 'Cuentasbancaria.cuenta'));
        $tramites = $this->Tramite->find('list',array('fields' => 'Tramite.nombre'));
        $this->set(compact('cuentas','tramites'));
    }
    public function elimina($idIngreso = null)
    {
        if($this->Ingreso->delete($idIngreso))
        {
            $this->Session->setFlash('Se elimino correctamnete!!!','msgbueno');
            $this->redirect(array('action' =>'index'));
        }
        else{
            $this->Session->setFlash('No se pudo eliminar!!!','msgerror');
            $this->redirect(array('action' =>'index'));
        }
    }
    public function listaexamenes()
    {
        $examenes = $this->Examene->find('all');
        $this->set(compact('examenes'));
    }
    public function nuevoexamen($idExamen = null)
    {
        $this->layout = 'ajax';
        $this->Examene->id = $idExamen;
        $this->request->data = $this->Examene->read();
    }
    public function guardaexamen()
    {
        if(!empty($this->request->data))
        {
            $this->Examene->create();
            $this->Examene->save($this->request->data['Examene']);
            $this->Session->setFlash('Se guardo correctamente!!!','msgbueno');
        }
        else{
            $this->Session->setFlash('No se pudo guardar!!!','msgerror');
        }
        $this->redirect($this->referer());
    }
    public function eliminaexamen($idExamen = null)
    {
        if($this->Examene->delete($idExamen))
        {
            $this->Session->setFlash('Se elimino correctamnete!!!' ,'msgbueno');
            
        }
        else{
            $this->Session->setFlash('No se puedo eliminar!!!','msgerror');
        }    
        $this->redirect($this->referer());
    }
    public function listacuentasbancarias()
    {
        $cuentas = $this->Cuentasbancaria->find('all');
        $this->set(compact('cuentas'));
    }
    public function nuevacuentabancaria($idCuenta = null)
    {
        $this->layout = 'ajax';
        $this->Cuentasbancaria->id = $idCuenta;
        $this->request->data = $this->Cuentasbancaria->read();
        
        $sucursales = $this->Sucursale->find('list',array('fields' => 'Sucursale.nombre'));
        $this->set(compact('sucursales'));
    }
    public function guardacuentab()
    {
        if(!empty($this->request->data))
        {
            $this->Cuentasbancaria->create();
            $this->Cuentasbancaria->save($this->request->data['Cuentasbancaria']);
            $this->Session->setFlash('Se guardo correctamente!!!','msgbueno');
        }
        else{
            $this->Session->setFlash('No se pudo guardar!!!','msgerror');
        }
        $this->redirect($this->referer());
    }
    public function eliminacuentab($idCuenta = null)
    {
        if($this->Cuentasbancaria->delete($idCuenta))
        {
            $this->Session->setFlash('Se elimino correctamnete!!!' ,'msgbueno');
            
        }
        else{
            $this->Session->setFlash('No se puedo eliminar!!!','msgerror');
        }    
        $this->redirect($this->referer());
    }
    public function listasucursales()
    {
        $sucursales = $this->Sucursale->find('all');
        $this->set(compact('sucursales'));
    }
    public function nuevasucursal($idSucursal = null)
    {
        $this->layout = 'ajax';
        $this->Sucursale->id = $idSucursal;
        $this->request->data = $this->Sucursale->read();
    }
    public function guardasucursal()
    {
        if(!empty($this->request->data))
        {
            $this->Sucursale->create();
            $this->Sucursale->save($this->request->data['Sucursale']);
            $this->Session->setFlash('Se guardo correctamente!!!','msgbueno');
        }
        else{
            $this->Session->setFlash('No se pudo guardar!!!','msgerror');
        }
        $this->redirect($this->referer());
    }
    public function eliminasucursal($idSucursal = null)
    {
        if($this->Sucursale->delete($idSucursal))
        {
            $this->Session->setFlash('Se elimino correctamnete!!!' ,'msgbueno');
            
        }
        else{
            $this->Session->setFlash('No se puedo eliminar!!!','msgerror');
        }    
        $this->redirect($this->referer());
    }
}
?>