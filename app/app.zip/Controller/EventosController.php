<?php

class EventosController extends AppController
{
    public $uses = array(
        'Evento',
        'EventosMascota',
        'Criadero',
        'Propietario',
        'Calificacione',
        'Mascota',
        'Raza',
        'Pista',
        'Mascotastitulo',
        'EventosPista',
        'EventosMascota',
        'Denuncianacimiento',
        'EventosMascotasPuntaje',
        'Categoriaspista', 
        'EventosMascotasPuntaje');
    public $layout = 'kennel';
    public $components = array(
        'Session');

    public function index()
    {
        $eventos = $this->Evento->find('all', array(
            'recursive' => 0,
            'order' => 'Evento.id DESC',
            'limit' => 15));
        //debug($mascotas);exit;
        $this->Evento->find('all');
        $this->set(compact('eventos'));
    }
    public function insertar()
    {

        if (!empty($this->data)) {
            
            if ($this->Evento->save($this->request->data)) {
                $idEvento = $this->Evento->getLastInsertID();
                $this->Session->setFlash("Evento guardado Correctamente",'msgbueno');
                $this->redirect(array('controller' => 'Eventos', 'action' => 'exposicion', $idEvento));
            } else {
                $this->Session->setFlash("No se pudo guardar",'msgerror');
                $this->redirect(array('controller' => 'Eventos', 'action' => 'index'));
            }
        }
    }
	public function delete($id = null)
    {
        $this->Evento->id = $id;
        $this->request->data = $this->Evento->read();
        if (!$id)
        {
            $this->Session->setFlash('No existe el Evento a eliminar');
            $this->redirect(array('action' => 'index'));
        } else
        {
            if ($this->Evento->delete($id))
            {
                $this->Session->setFlash('Se elimino el Evento ' . $this->data['Evento']['nombre'], 'msgbueno');
                $this->redirect(array('action' => 'index'));
            } else
            {
                $this->Session->setFlash('Error al eliminar');
            }
        }
    }
    public function exposicion($idEvento = null)
    {
        //debug($idEvento);exit;
        $evento = $this->Evento->find('first',array('recursive' => 2,'conditions' => array('Evento.id' => $idEvento)));
        $cate = $this->Categoriaspista->find('all');
        //$inscritos = $this->EventosMascota->find('all');
        //debug($inscritos);exit;
        $pistas = $this->EventosPista->find('all',array('conditions' => array('EventosPista.evento_id' => $idEvento)));
        //debug($pistas);exit;
        $mejoresespeciales = $this->EventosMascota->find('all',array('order' => 'EventosMascota.puesto ASC','recursive' => 2,'conditions' => array('EventosMascota.evento_id' => $idEvento,'EventosMascota.categoriaspista_id' => 1)));
        $mejoresabsolutos = $this->EventosMascota->find('all',array('recursive' => 2,'order' => 'EventosMascota.puesto ASC','conditions' => array('EventosMascota.evento_id' => $idEvento,'EventosMascota.categoriaspista_id' => 2)));
        $selecpistas = $this->Pista->find('list',array('fields' => 'Pista.nombre'));
        //$eventopis = $this->EventosPista->find('all',array('conditions' => array('EventosPista.evento_id' => $idEvento)));
        //$listcalificaciones = $this->Calificacione->find('list',array('fields' => 'Calificacione.nombre'));
        //debug($listcalificaciones);exit;
        $razas = $this->Raza->find('list',array('fields' => 'Raza.nombre'));
        $dcr = $this->Raza->find('list', array('recursive' => -1, 'fields' => array('nombre')));
        $criaderos = $this->Criadero->find('list', array('fields'=>array('Criadero.id', 'Criadero.nombre')));
        $this->set(compact('criaderos','dcr','evento','idEvento','cate','pistas','selecpistas','listcalificaciones','razas'));
    }
    public function ajaxlistado($idEvento = null)
    {
        //debug('eynaer');exit;
        
        $this->layout = 'ajax';
        
            if(!empty($this->request->data['Mascota']['nombre_completo']) and empty($this->request->data['Mascota']['kcb']) and empty($this->request->data['Mascota']['num_tatuaje']))
            {
                $mascotas = $this->Mascota->find('all',array('conditions'=>array('Mascota.nombre_completo LIKE'=> '%'.$this->request->data['Mascota']['nombre_completo'].'%')));
            }
            if(!empty($this->request->data['Mascota']['kcb'])and empty($this->request->data['Mascota']['nombre_completo']) and empty($this->request->data['Mascota']['num_tatuaje']))
            {
                $mascotas = $this->Mascota->find('all',array('conditions'=>array('Mascota.kcb LIKE'=> '%'.$this->request->data['Mascota']['kcb'].'%')));
            }
            if(!empty($this->request->data['Mascota']['num_tatuaje'])and empty($this->request->data['Mascota']['nombre_completo']) and empty($this->request->data['Mascota']['kcb']))
            {
                $mascotas = $this->Mascota->find('all',array('conditions'=>array('Mascota.num_tatuaje LIKE'=> '%'.$this->request->data['Mascota']['num_tatuaje'].'%')));
            }
            if(!empty($this->request->data['Mascota']['num_tatuaje'])and !empty($this->request->data['Mascota']['nombre_completo']) and empty($this->request->data['Mascota']['kcb']))
            {
                $mascotas = $this->Mascota->find('all',array('conditions'=>array('Mascota.num_tatuaje LIKE'=> '%'.$this->request->data['Mascota']['num_tatuaje'].'%',
                'Mascota.nombre_completo LIKE'=> '%'.$this->request->data['Mascota']['nombre_completo'].'%')));
            }
            if(!empty($this->request->data['Mascota']['num_tatuaje'])and empty($this->request->data['Mascota']['nombre_completo']) and !empty($this->request->data['Mascota']['kcb']))
            {
                $mascotas = $this->Mascota->find('all',array('conditions'=>array('Mascota.num_tatuaje LIKE'=> '%'.$this->request->data['Mascota']['num_tatuaje'].'%',
                'Mascota.kcb LIKE'=> '%'.$this->request->data['Mascota']['kcb'].'%')));
            }
            if(empty($this->request->data['Mascota']['num_tatuaje'])and !empty($this->request->data['Mascota']['nombre_completo']) and !empty($this->request->data['Mascota']['kcb']))
            {
                $mascotas = $this->Mascota->find('all',array('conditions'=>array('Mascota.kcb LIKE'=> '%'.$this->request->data['Mascota']['kcb'].'%',
                'Mascota.nombre_completo LIKE'=> '%'.$this->request->data['Mascota']['nombre_completo'].'%')));
            }
            if(!empty($this->request->data['Mascota']['num_tatuaje'])and !empty($this->request->data['Mascota']['nombre_completo']) and !empty($this->request->data['Mascota']['kcb']))
            {
                $mascotas = $this->Mascota->find('all',array('conditions'=>array('Mascota.kcb LIKE'=> '%'.$this->request->data['Mascota']['kcb'].'%',
                'Mascota.nombre_completo LIKE'=> '%'.$this->request->data['Mascota']['nombre_completo'].'%',
                'Mascota.num_tatuaje LIKE'=> '%'.$this->request->data['Mascota']['num_tatuaje'].'%')));
            }
            
        $catepistas = $this->Categoriaspista->find('list',array('fields' => 'Categoriaspista.nombre'));
        //debug($this->request->data);exit;
        //debug($mascotas);exit;
        $this->set(compact('mascotas','catepistas','idEvento'));
    }
    public function ajaxformulario($id = null, $idEvento = null)
    {
        $this->layout = 'ajax';
        //debug($id);exit;
        $evento = $this->Evento->find('first',array('conditions' => array('Evento.id' => $idEvento)));
        $fecha1 = $evento['Evento']['fecha_inicio'];
        $mas = $this->Mascota->find('first',array('conditions' => array('Mascota.id' => $id)));
        $catepistas = $this->Categoriaspista->find('list',array('fields' => 'Categoriaspista.nombre'));
        //debug($mas);exit;
        $titulos = $this->Mascotastitulo->find('all',array('conditions' => array('Mascotastitulo.mascota_id' => $id)));
        
        $this->set(compact('mas','catepistas','idEvento','fecha1','titulos'));
    }
    public function actualiza()
    {
        //debug($this->request->data);exit;
        if(!empty($this->data)){
            $this->EventosPista->create();
            $idEvento = $this->request->data['EventosPista']['evento_id'];
            if($this->EventosPista->save($this->data)){
                
                //$this->Session->setFlash("Raza".$this->Raza->id." guardada");
                $this->redirect(array('controller' => 'Eventos', 'action' => 'exposicion', $idEvento));
            }else{
                //$this->Session->setFlash("No se pudo guardar");
                $this->redirect(array('controller' => 'Eventos', 'action' => 'exposicion', $idEvento));
            }
        }
        
    }
    public function ajaxpistas($idEvento = null,$pista = null)
    {
        $this->layout = 'ajax';
        //debug($this->request->data);
        //debug($idEvento);
        //debug($pista);exit;
        $p = $this->EventosPista->find('first',array('conditions' => array('EventosPista.id' => $pista)));
        
        
        if($this->request->data['Raza']['raza'] == 'todos')
        {
            $cachoespe = $this->EventosMascotasPuntaje->find('all',array('recursive' => 0,
                                            'conditions' =>array(
                                            'EventosMascotasPuntaje.evento_id' => $idEvento,
                                            'EventosMascotasPuntaje.eventospista_id' => $pista,
                                            '')
                                            ));
            $sw = 1;
            $nomraza = 'TODAS';
        }
        else{
            $raza = $this->Raza->find('first',array('conditions' => array('Raza.id' => $this->request->data['Raza']['raza'])) );
            $cachoespe = $this->EventosMascotasPuntaje->find('all',array('recursive' => 0,
                                            'conditions' =>array(
                                            'EventosMascotasPuntaje.evento_id' => $idEvento,
                                            'EventosMascotasPuntaje.eventospista_id' => $pista,
                                            'EventosMascotasPuntaje.raza_id' => $this->request->data['Raza']['raza'])
                                            ));
            $sw = 0;
            $nomraza = $raza['Raza']['nombre'];
        }
        
                                            
        $listcalificaciones = $this->Calificacione->find('list',array('fields' => 'Calificacione.nombre'));
        //debug($listcalificaciones);exit;
        $this->set(compact('pista','idEvento','cachoespe','p','listcalificaciones','sw','nomraza'));
    }
    public function ajaxinscritos($idEvento = null)
    {
        $this->layout = 'ajax';
        $evento = $this->Evento->find('first',array('conditions' => array('Evento.id' => $idEvento)));
        $fecha1 = $evento['Evento']['fecha_inicio'];
        //debug($idEvento);
        //debug($this->request->data);exit;
        if(!empty($this->data)){
            $this->EventosMascota->create();
            $this->request->data['EventosMascota']['evento_id'] = $idEvento;
            $idmascota = $this->request->data['EventosMascota']['mascota_id'];
            $mascota = $this->Mascota->find('first',array('conditions' => array('Mascota.id' => $idmascota)));
            //debug($mascota);exit;
            $existe = $this->EventosMascota->find('first',array('conditions' => array('EventosMascota.mascota_id' => $idmascota,'EventosMascota.evento_id' => $idEvento)));
            if(!empty($existe))
            {
                $mensajem = $mascota['Mascota']['nombre_completo'].' ya esta inscrito!!!';
            }
            else{
                $fecha2 = $mascota['Mascota']['fecha_nacimiento'];
            $edad = $this->meses($fecha2,$fecha1);
            //debug($edad);exit;
            $pista = $this->Categoriaspista->find('first',array('conditions' => array('Categoriaspista.id' => $this->request->data['EventosMascota']['categoriaspista_id'])));
            if($pista['Categoriaspista']['id'] != 9 and $pista['Categoriaspista']['id'] != 10)
            {
                if($edad >= $pista['Categoriaspista']['desde'] and $edad <= $pista['Categoriaspista']['hasta'])
                {
                    if($this->EventosMascota->save($this->data)){
                        $mensajeb = 'SE INSCRIBIO CORRECTAMENTE LA MASCOTA!!!';
                    }else{
                        $mensajem = 'ERROR NO SE PUDO INSCRIBIR!!!';
                    }
                }
                else{
                    $mensajem = 'NO SE PUEDE SU EDAD ES '.$edad.' MESES';
                }
            }
            else{
                $masti = $this->Mascotastitulo->find('first',array('conditions' => array('Mascotastitulo.mascota_id' => $idmascota,'Mascotastitulo.titulo_id' => 2)));
                if(!empty($masti))
                {
                    if($this->EventosMascota->save($this->data)){
                        $mensajeb = 'SE INSCRIBIO CORRECTAMENTE LA MASCOTA!!!';
                    }else{
                        $mensajem = 'ERROR NO SE PUDO INSCRIBIR!!!';
                    }
                }
                else{
                    $mensajem = 'NO PUEDE NO TIENE TITULO!!!';
                }
                    
            }
            }
        }
        $cate = $this->Categoriaspista->find('all');
        $this->set(compact('mensajeb','mensajem','cate','idEvento'));
    }
    function meses($fech_ini,$fech_fin) {
       
       $fIni_yr=substr($fech_ini,0,4);
        $fIni_mon=substr($fech_ini,5,2);
        $fIni_day=substr($fech_ini,8,2);
    
       //SEPARO LOS VALORES DEL ANIO, MES Y DIA PARA LA FECHA FINAL EN DIFERENTES
       //VARIABLES PARASU MEJOR MANEJO
       $fFin_yr=substr($fech_fin,0,4);
        $fFin_mon=substr($fech_fin,5,2);
        $fFin_day=substr($fech_fin,8,2);
    
       $yr_dif=$fFin_yr - $fIni_yr;
       //echo "la diferencia de a�os es -> ".$yr_dif."<br>";
       //LA FUNCION strtotime NOS PERMITE COMPARAR CORRECTAMENTE LAS FECHAS
       //TAMBIEN ES UTIL CON LA FUNCION date
       if(strtotime($fech_ini) > strtotime($fech_fin)){
          echo 'ERROR -> la fecha inicial es mayor a la fecha final <br>';
          exit();
       }
       else{
           if($yr_dif == 1){
             $fIni_mon = 12 - $fIni_mon;
             $meses = $fFin_mon + $fIni_mon;
             return $meses;
             //LA FUNCION utf8_encode NOS SIRVE PARA PODER MOSTRAR ACENTOS Y
             //CARACTERES RAROS
             //echo utf8_encode("la diferencia de meses con un a�o de diferencia es -> ".$meses."<br>");
          }
          else{
              if($yr_dif == 0){
                 $meses=$fFin_mon - $fIni_mon;
                return $meses;
                //echo utf8_encode("la diferencia de meses con cero a�os de diferencia es -> ".$meses.", donde el mes inicial es ".$fIni_mon.", el mes final es ".$fFin_mon."<br>");
             }
             else{
                 if($yr_dif > 1){
                   $fIni_mon = 12 - $fIni_mon;
                   $meses = $fFin_mon + $fIni_mon + (($yr_dif - 1) * 12);
                   return $meses;
                   //echo utf8_encode("la diferencia de meses con mas de un a�o de diferencia es -> ".$meses."<br>");
                }
                else
                   echo "ERROR -> la fecha inicial es mayor a la fecha final <br>";
                   exit();
             }
          }
       }
    
    }
    public function actualizapistas($idEvento = null)
    {
        $evenpis = $this->EventosPista->find('all', array('conditions' => array('EventosPista.evento_id' => $idEvento)));
        $inscritos = $this->EventosMascota->find('all',array('conditions' => array('EventosMascota.evento_id' => $idEvento)));
        foreach($inscritos as $in)
        {
            foreach($evenpis as $ev)
            {
                
                $this->EventosMascotasPuntaje->create();
                $this->request->data['EventosMascotasPuntaje']['mascota_id'] = $in['EventosMascota']['mascota_id'];
                $this->request->data['EventosMascotasPuntaje']['raza_id'] = $in['Mascota']['raza_id'];
                $this->request->data['EventosMascotasPuntaje']['categoriaspista_id'] = $in['EventosMascota']['categoriaspista_id'];
                $this->request->data['EventosMascotasPuntaje']['evento_id'] = $idEvento;
                $this->request->data['EventosMascotasPuntaje']['eventosmascota_id'] = $in['EventosMascota']['id'];
                $this->request->data['EventosMascotasPuntaje']['eventospista_id'] = $ev['EventosPista']['id'];
                $evenmaspun = $this->EventosMascotasPuntaje->find('first',
                array('conditions' => array(
                'EventosMascotasPuntaje.mascota_id' => $in['EventosMascota']['mascota_id'],
                'EventosMascotasPuntaje.evento_id' => $idEvento,
                'EventosMascotasPuntaje.eventosmascota_id' => $in['EventosMascota']['id'],
                'EventosMascotasPuntaje.eventospista_id' => $ev['EventosPista']['id']
                )
                ));
                if(empty($evenmaspun))
                {
                    $this->EventosMascotasPuntaje->save($this->request->data);   
                }
            }
        }
        $this->redirect(array('controller' => 'Eventos', 'action' => 'exposicion', $idEvento));
    }
    public function ajaxespegrupo($idEvento = null,$cant = null,$pista = null)
    {
        $this->layout = 'ajax';
        //debug($cant);
        //debug($idEvento);
        //debug($pista);
        //debug($this->request->data);exit;
        for($i=1;$i<=$cant;$i++)
        {
            if(!empty($this->request->data['Numero']))
            {
                $this->EventosPista->id = $pista;
                $this->request->data['EventosPista']['numero_especiales'] = $this->request->data['Numero']['numero_especiales'];
                $this->request->data['EventosPista']['numero_absolutos'] = $this->request->data['Numero']['numero_absolutos'];
                $this->request->data['EventosPista']['numero_jovenes'] = $this->request->data['Numero']['numero_jovenes'];
                $this->request->data['EventosPista']['numero_adultos'] = $this->request->data['Numero']['numero_adultos'] + $this->request->data['Numero']['numero_jovenes'];
                $this->EventosPista->save($this->request->data['EventosPista']);
            }
            if(!empty($this->request->data['EventosMascotasPuntaje'][$i]))
            {
                $idemp = $this->request->data['EventosMascotasPuntaje'][$i]['id'];
                //$evenmaspun = $this->EventosMascotasPuntaje->find('first',array('conditions' => array('EventosMascotasPuntaje.id' => $idemp)));
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['mejor_cachorro']))
                {
                    $mc = $this->request->data['EventosMascotasPuntaje'][$i]['mejor_cachorro'];
                }
                else{
                    $mc = null;
                }
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['mejor_cachorro_opuesto']))
                {
                    $mco = $this->request->data['EventosMascotasPuntaje'][$i]['mejor_cachorro_opuesto'];
                }
                else{
                    $mco = null;
                }
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['puntaje_cac']))
                {
                    $pcac = $this->request->data['EventosMascotasPuntaje'][$i]['puntaje_cac'];
                }
                else{
                    $pcac = null;
                }
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['cacib']))
                {
                    $cacib = $this->request->data['EventosMascotasPuntaje'][$i]['cacib'];
                }
                else{
                    $cacib = null;
                }
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['caclab']))
                {
                    $caclab = $this->request->data['EventosMascotasPuntaje'][$i]['caclab'];
                }
                else{
                    $caclab = null;
                }
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['cgc']))
                {
                    $cgc = $this->request->data['EventosMascotasPuntaje'][$i]['cgc'];
                }
                else{
                    $cgc = null;
                }
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['cac']))
                {
                    $cac = $this->request->data['EventosMascotasPuntaje'][$i]['cac'];
                }
                else{
                    $cac = null;
                }
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['cjc']))
                {
                    $cjc = $this->request->data['EventosMascotasPuntaje'][$i]['cjc'];
                }
                else{
                    $cjc = null;
                }
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['puesto_exposicion_adultos']))
                {
                    $puestoa = $this->request->data['EventosMascotasPuntaje'][$i]['puesto_exposicion_adultos'];
                }
                else{
                    $puestoa = null;
                }
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['puesto_exposicion']))
                {
                    $puesto = $this->request->data['EventosMascotasPuntaje'][$i]['puesto_exposicion'];
                }
                else{
                    $puesto = null;
                }
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['reserva_grupo_adultos']))
                {
                    $rgrua = $this->request->data['EventosMascotasPuntaje'][$i]['reserva_grupo_adultos'];
                }
                else{
                    $rgrua = null;
                }
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['mejor_grupo_adultos']))
                {
                    $mgrua = $this->request->data['EventosMascotasPuntaje'][$i]['mejor_grupo_adultos'];
                }
                else{
                    $mgrua = null;
                }
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['reserva_grupo']))
                {
                    $rgru = $this->request->data['EventosMascotasPuntaje'][$i]['reserva_grupo'];
                }
                else{
                    $rgru = null;
                }
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['mejor_grupo']))
                {
                    $mgru = $this->request->data['EventosMascotasPuntaje'][$i]['mejor_grupo'];
                }
                else{
                    $mgru = null;
                }
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['calificacione_id']))
                {
                    $cali = $this->request->data['EventosMascotasPuntaje'][$i]['calificacione_id'];
                }
                else{
                    $cali = null;
                }
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['mejor_raza_adulto_sexo_opuesto']))
                {
                   $mao = $this->request->data['EventosMascotasPuntaje'][$i]['mejor_raza_adulto_sexo_opuesto']; 
                }
                else{
                    $mao = null;
                }
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['mejor_raza_adulto']))
                {
                    $ma = $this->request->data['EventosMascotasPuntaje'][$i]['mejor_raza_adulto'];
                }
                else{
                    $ma = null;
                }
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['mejor_raza_joven_sexo_opuesto']))
                {
                    $mjo = $this->request->data['EventosMascotasPuntaje'][$i]['mejor_raza_joven_sexo_opuesto'];
                }
                else{
                    $mjo = null;
                }
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['mejor_raza_joven']))
                {
                    $mj = $this->request->data['EventosMascotasPuntaje'][$i]['mejor_raza_joven'];
                }
                else{
                    $mj = null;
                }
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['puntaje_cgc']))
                {
                    $pcgc = $this->request->data['EventosMascotasPuntaje'][$i]['puntaje_cgc'];
                }
                else{
                    $pcgc = null;
                }
                if(!empty($this->request->data['EventosMascotasPuntaje'][$i]['categoriaspista_id']))
                {
                    $catepista = $this->request->data['EventosMascotasPuntaje'][$i]['categoriaspista_id'];
                }
                else{
                    $catepista = null;
                }
                 
                
                $nespeciales = $this->request->data['Numero']['numero_especiales'];
                $nabsolutos = $this->request->data['Numero']['numero_absolutos'];
                $njovenes = $this->request->data['Numero']['numero_jovenes'];
                $nadultos = $this->request->data['Numero']['numero_adultos'] + $this->request->data['Numero']['numero_jovenes'];
                $puntos = 0;
                $puntos2 = 0;
                
                $this->EventosMascotasPuntaje->id = $idemp;
                
               
                
                if($catepista == 1)
                {
                    $numerototal = $nespeciales;
                }
                if($catepista == 2)
                {
                    $numerototal = $nabsolutos;
                }
                if($catepista == 3 || $catepista == 4)
                {
                    $numerototal = $njovenes;
                    $numerototal2 = $nadultos;
                }
                if($catepista == 5 || $catepista == 6 || $catepista == 7 || $catepista == 8 || $catepista == 9 || $catepista == 10)
                {
                    $numerototal2 = $nadultos;
                }
                
                $this->request->data['EventosMascotasPuntaje']['mejor_cachorro'] = $mc;
                $this->request->data['EventosMascotasPuntaje']['mejor_cachorro_opuesto'] = $mco;
                $this->request->data['EventosMascotasPuntaje']['mejor_raza_joven'] = $mj;
                $this->request->data['EventosMascotasPuntaje']['mejor_raza_joven_sexo_opuesto'] = $mjo;
                $this->request->data['EventosMascotasPuntaje']['mejor_raza_adulto'] = $ma;
                $this->request->data['EventosMascotasPuntaje']['mejor_raza_adulto_sexo_opuesto'] = $mao;
                $this->request->data['EventosMascotasPuntaje']['calificacione_id'] = $cali;
                $this->request->data['EventosMascotasPuntaje']['mejor_grupo'] = $mgru;
                $this->request->data['EventosMascotasPuntaje']['reserva_grupo'] = $rgru;
                $this->request->data['EventosMascotasPuntaje']['mejor_grupo_adultos'] = $mgrua;
                $this->request->data['EventosMascotasPuntaje']['reserva_grupo_adultos'] = $rgrua;
                $this->request->data['EventosMascotasPuntaje']['puesto_exposicion'] = $puesto;
                $this->request->data['EventosMascotasPuntaje']['puesto_exposicion_adultos'] = $puestoa;
                $this->request->data['EventosMascotasPuntaje']['cjc'] = $cjc;
                $this->request->data['EventosMascotasPuntaje']['cac'] = $cac;
                $this->request->data['EventosMascotasPuntaje']['cgc'] = $cgc;
                $this->request->data['EventosMascotasPuntaje']['caclab'] = $caclab;
                $this->request->data['EventosMascotasPuntaje']['cacib'] = $cacib;
                $this->request->data['EventosMascotasPuntaje']['puntaje_cac'] = $pcac;
                $this->request->data['EventosMascotasPuntaje']['puntaje_cgc'] = $pcgc;
                
                
                if(!empty($numerototal))
                {
                     if ($puesto == 1)
                    {
                        $puntos = $numerototal;
                    }
                    if ($puesto == 2)
                    {
                        $puntos = ($numerototal * 80)/100;
                    }
                    if ($puesto == 3)
                    {
                        $puntos = ($numerototal * 60)/100;
                    }
                    if ($puesto == 4)
                    {
                        $puntos = ($numerototal * 40)/100;
                    }
                    if ($puesto == 5)
                    {
                        $puntos = ($numerototal * 20)/100;
                    }
                }
                if(!empty($numerototal2))
                {
                     if ($puestoa == 1)
                    {
                        $puntos2 = $numerototal2;
                    }
                    if ($puestoa == 2)
                    {
                        $puntos2 = ($numerototal2 * 80)/100;
                    }
                    if ($puestoa == 3)
                    {
                        $puntos2 = ($numerototal2 * 60)/100;
                    }
                    if ($puestoa == 4)
                    {
                        $puntos2 = ($numerototal2 * 40)/100;
                    }
                    if ($puestoa == 5)
                    {
                        $puntos2 = ($numerototal2 * 20)/100;
                    }
                }
               
                $this->request->data['EventosMascotasPuntaje']['puntosex'] = $puntos;
                $this->request->data['EventosMascotasPuntaje']['puntosex_adultos'] = $puntos2;
                
                if($this->EventosMascotasPuntaje->save($this->request->data['EventosMascotasPuntaje'])){
                    $mensajeb = 'SE GUARDO CORRECTAMENTE!!!';
                }
                else{
                    $mensajem = 'NO SE PUDO GUARDAR!!!';
                }
            }
        }
        
        $this->set(compact('cachomejoresespeciales','pista','idEvento','mensajeb','mensajem'));
        //debug($cachomejoresespeciales);exit;
    }
    public function exporeporte($idEvento = null,$sw = null)
    {
        //debug($idEvento);exit;
        $evento = $this->Evento->find('first',array('recursive' => 2,'conditions' => array('Evento.id' => $idEvento)));
        //$cate = $this->Categoriaspista->find('all');
        $puntos = 0.00;
        if($sw == 1)
        {
            $mascotas = $this->EventosMascotasPuntaje->find('all',array('conditions' => array('EventosMascotasPuntaje.evento_id' => $idEvento)));
            foreach($mascotas as $m)
            {
                $puntos = 0.00;
                $puntosadultos = 0.00;
                $id = $m['EventosMascotasPuntaje']['id'];
                //$puntos = $m['EventosMascotasPuntaje']['puntos'];
                $cate = $m['EventosMascotasPuntaje']['categoriaspista_id'];
                if($cate == 1 || $cate == 2)
                {
                    $s1 = $s2 = $s3 = $s4 = 0.00;
                    
                    $s5 = $m['EventosMascotasPuntaje']['puntosex'];
                    $puntos = $s1 + $s2 + $s3 + $s4 + $s5;
                }
                if($cate == 3 || $cate == 4)
                {
                    $s1 = $s2 = $s3 = $s4 = 0.00;
                    if($m['EventosMascotasPuntaje']['mejor_raza_joven'] == 1)
                    {
                        $s1 = 10;
                    }
                    if($m['EventosMascotasPuntaje']['mejor_raza_joven_sexo_opuesto'] == 1)
                    {
                        $s2 = 5;
                    }
                    if($m['EventosMascotasPuntaje']['mejor_grupo'] == 1)
                    {
                        $s3 = 20;
                    }
                    if($m['EventosMascotasPuntaje']['reserva_grupo'] == 1)
                    {
                        $s4 = 10;
                    }
                    $s5 = $m['EventosMascotasPuntaje']['puntosex'];
                    $puntos = $s1 + $s2 + $s3 + $s4 + $s5;
                }
                if($cate == 3 || $cate == 4 || $cate == 5 || $cate == 6|| $cate == 7|| $cate == 8|| $cate == 9|| $cate == 10)
                {
                    $s5 = 0.00;
                    $s1 = $s2 = $s3 = $s4 = 0.00;
                    if($m['EventosMascotasPuntaje']['mejor_raza_adulto'] == 1)
                    {
                        $s1 = 10;
                    }
                    if($m['EventosMascotasPuntaje']['mejor_raza_adulto_sexo_opuesto'] == 1)
                    {
                        $s2 = 5;
                    }
                    if($m['EventosMascotasPuntaje']['mejor_grupo_adultos'] == 1)
                    {
                        $s3 = 20;
                    }
                    if($m['EventosMascotasPuntaje']['reserva_grupo_adultos'] == 1)
                    {
                        $s4 = 10;
                    }
                    $s5 = $m['EventosMascotasPuntaje']['puntosex_adultos'];
                    $puntosadultos = $s1 + $s2 + $s3 + $s4 + $s5;
                }
                $this->EventosMascotasPuntaje->id = $id;
                $this->request->data['EventosMascotasPuntaje']['puntos'] = $puntos;
                $this->request->data['EventosMascotasPuntaje']['puntos_adultos'] = $puntosadultos;
                $this->EventosMascotasPuntaje->save($this->data);
            }
        }
        else{
            
        }
        //$inscritos = $this->EventosMascota->find('all');
        //debug($inscritos);exit;
        $pistas = $this->EventosPista->find('all',array('conditions' => array('EventosPista.evento_id' => $idEvento)));
        //debug($pistas);exit;
        $mejoresespeciales = $this->EventosMascota->find('all',array('order' => 'EventosMascota.puesto ASC','recursive' => 2,'conditions' => array('EventosMascota.evento_id' => $idEvento,'EventosMascota.categoriaspista_id' => 1)));
        $mejoresabsolutos = $this->EventosMascota->find('all',array('recursive' => 2,'order' => 'EventosMascota.puesto ASC','conditions' => array('EventosMascota.evento_id' => $idEvento,'EventosMascota.categoriaspista_id' => 2)));
        
        
        $razas = $this->Raza->find('list',array('fields' => 'Raza.nombre'));
        $this->set(compact('evento','idEvento','cate','pistas','razas'));
    }
    public function ajaxpistasfinal($idEvento = null,$pista = null)
    {
        $this->layout = 'ajax';
        //debug($this->request->data);
        //debug($idEvento);
        //debug($pista);exit;
        $p = $this->EventosPista->find('first',array('conditions' => array('EventosPista.id' => $pista)));
        
        
        if($this->request->data['Raza']['raza'] == 'todos')
        {
            $cachoespe = $this->EventosMascotasPuntaje->find('all',array('recursive' => 0,
                                            'conditions' =>array(
                                            'EventosMascotasPuntaje.evento_id' => $idEvento,
                                            'EventosMascotasPuntaje.eventospista_id' => $pista,
                                            '')
                                            ));
            $sw = 1;
            $nomraza = 'TODAS';
        }
        else{
            $raza = $this->Raza->find('first',array('conditions' => array('Raza.id' => $this->request->data['Raza']['raza'])) );
            $cachoespe = $this->EventosMascotasPuntaje->find('all',array('recursive' => 0,
                                            'conditions' =>array(
                                            'EventosMascotasPuntaje.evento_id' => $idEvento,
                                            'EventosMascotasPuntaje.eventospista_id' => $pista,
                                            'EventosMascotasPuntaje.raza_id' => $this->request->data['Raza']['raza'])
                                            ));
            $sw = 0;
            $nomraza = $raza['Raza']['nombre'];
        }
        
                                            
        $listcalificaciones = $this->Calificacione->find('list',array('fields' => 'Calificacione.nombre'));
        //debug($listcalificaciones);exit;
        $this->set(compact('pista','idEvento','cachoespe','p','listcalificaciones','sw','nomraza'));
    }
    public function quitainscripcion($idEvenMas = null)
    {
        if($this->EventosMascota->delete($idEvenMas))
        {
            $this->Session->setFlash('Se retiro correctamente del Evento','msgbueno');
            $this->EventosMascotasPuntaje->deleteAll(array('EventosMascotasPuntaje.eventosmascota_id' => $idEvenMas));
        }
        else{
            $this->Session->setFlash('No se pudo retirar del evento intente nuevamente','msgerror');
        }
        $this->redirect($this->referer());
    }
    public function edita($idEvento = null)
    {
        $this->layout = 'ajax';
        //debug($idEvento);exit;
        $this->Evento->id = $idEvento;
        $this->request->data = $this->Evento->read();
        //debug($this->request->data);exit;
        
    }
    public function guardaevento()
    {
        if(!empty($this->request->data))
        {
            $this->Evento->create();
            $this->Evento->save($this->request->data);
            $this->Session->setFlash('Se guardo correctamente!!!','msgbueno');
        }
        else{
            $this->Session->setFlash('No se guardo intente de nuevo!!!!','msgerror');
        }
        $this->redirect($this->referer());
    }
    public function reportegeneral($idEvento = null)
    {
        //$this->layout = '';
        
        $mascotas = $this->EventosMascota->find('all',array('recursive' => 2,'conditions' => array('EventosMascota.evento_id' => $idEvento)));
        //debug($mascotas);exit;
        $pistas = $this->EventosPista->find('all',array('recursive' => 0,'conditions' => array('EventosPista.evento_id' => $idEvento)));
        //debug($pistas);exit;
        $evento = $this->Evento->find('first',array('conditions' => array('Evento.id' => $idEvento)));
        //debug($evento);exit;
        $this->set(compact('mascotas','pistas','evento','idEvento'));
    }
    public function ranking_especiales($idEvento = null,$ano = null)
    {
        if(!empty($ano))
        {
            //$evento = $this->Evento->findByid($idEvento,null,null,null,null,-1);
            $ranking = $this->EventosMascotasPuntaje->find('all',array('recursive' => 2,'order' => 'EventosMascotasPuntaje.puntos ASC','conditions' => array('Year(Evento.fecha_inicio)' => $ano,'EventosMascotasPuntaje.categoriaspista_id' => 1)));
        }
        else{
            $evento = $this->Evento->findByid($idEvento,null,null,null,null,-1);
            $ranking = $this->EventosMascotasPuntaje->find('all',array('recursive' => 2,'order' => 'EventosMascotasPuntaje.puntos ASC','conditions' => array('EventosMascotasPuntaje.evento_id' => $idEvento,'EventosMascotasPuntaje.categoriaspista_id' => 1)));
        }
        
        //debug($ranking);exit;
        $this->set(compact('ranking','evento','idEvento','ano'));
    }
    public function ranking_razas_especiales($idEvento = null,$ano = null)
    {
        $evento = $this->Evento->findByid($idEvento,null,null,null,null,-1);
        
        $razas = $this->Raza->find('all', array('order' => 'Raza.nombre ASC'));
        $this->set(compact('ranking','evento','idEvento','razas','ano'));
    }
    public function ranking_absolutos($idEvento = null,$ano = null)
    {
        if(!empty($ano))
        {
            //$evento = $this->Evento->findByid($idEvento,null,null,null,null,-1);
            $ranking = $this->EventosMascotasPuntaje->find('all',array('recursive' => 2,'order' => 'EventosMascotasPuntaje.puntos ASC','conditions' => array('Year(Evento.fecha_inicio)' => $ano,'EventosMascotasPuntaje.categoriaspista_id' => 2)));
        }
        else{
            $evento = $this->Evento->findByid($idEvento,null,null,null,null,-1);
            $ranking = $this->EventosMascotasPuntaje->find('all',array('recursive' => 2,'order' => 'EventosMascotasPuntaje.puntos ASC','conditions' => array('EventosMascotasPuntaje.evento_id' => $idEvento,'EventosMascotasPuntaje.categoriaspista_id' => 2)));
        }
        
        //debug($ranking);exit;
        $this->set(compact('ranking','evento','idEvento','ano'));
    }
    public function ranking_razas_absolutos($idEvento = null,$ano = null)
    {
        $evento = $this->Evento->findByid($idEvento,null,null,null,null,-1);
        
        $razas = $this->Raza->find('all', array('order' => 'Raza.nombre ASC'));
        $this->set(compact('ranking','evento','idEvento','razas','ano'));
    }
    public function ranking_jovenes($idEvento = null,$ano = null)
    {
        if(!empty($ano))
        {
            $ranking = $this->EventosMascotasPuntaje->find('all',array('recursive' => 2,'order' => 'EventosMascotasPuntaje.puntos ASC','conditions' => array('Year(Evento.fecha_inicio)' => $ano,'EventosMascotasPuntaje.categoriaspista_id' => array(3,4))));
        }
        else{
            $evento = $this->Evento->findByid($idEvento,null,null,null,null,-1);
            $ranking = $this->EventosMascotasPuntaje->find('all',array('recursive' => 2,'order' => 'EventosMascotasPuntaje.puntos ASC','conditions' => array('EventosMascotasPuntaje.evento_id' => $idEvento,'EventosMascotasPuntaje.categoriaspista_id' => array(3,4))));
        }
        
        //debug($ranking);exit;
        $this->set(compact('ranking','evento','idEvento','ano'));
    }
    public function ranking_razas_jovenes($idEvento = null,$ano = null)
    {
        $evento = $this->Evento->findByid($idEvento,null,null,null,null,-1);
        
        $razas = $this->Raza->find('all', array('order' => 'Raza.nombre ASC'));
        $this->set(compact('ranking','evento','idEvento','razas','ano'));
    }
    public function ranking_adultos($idEvento = null,$ano = null)
    {
        if(!empty($ano))
        {
            $ranking = $this->EventosMascotasPuntaje->find('all',array('recursive' => 2,'order' => 'EventosMascotasPuntaje.puntos ASC','conditions' => array('Year(Evento.fecha_inicio)' => $ano,'EventosMascotasPuntaje.categoriaspista_id' => array(5,6,7,8,9,10))));
        }
        else{
            $evento = $this->Evento->findByid($idEvento,null,null,null,null,-1);
            $ranking = $this->EventosMascotasPuntaje->find('all',array('recursive' => 2,'order' => 'EventosMascotasPuntaje.puntos ASC','conditions' => array('EventosMascotasPuntaje.evento_id' => $idEvento,'EventosMascotasPuntaje.categoriaspista_id' => array(5,6,7,8,9,10))));
        }
        //debug($ranking);exit;
        $this->set(compact('ranking','evento','idEvento','ano'));
    }
    public function ranking_razas_adultos($idEvento = null,$ano = null)
    {
        $evento = $this->Evento->findByid($idEvento,null,null,null,null,-1);
        
        $razas = $this->Raza->find('all', array('order' => 'Raza.nombre ASC'));
        $this->set(compact('ranking','evento','idEvento','razas','ano'));
    }
    public function reporte($idEvento = null)
    {
        $this->layout = 'ajax';
        $this->set(compact('idEvento'));
    }
    public function reportesanuales()
    {
        $this->layout = 'ajax';
        $eventos = $this->Evento->find('all',array('group' => 'YEAR(Evento.fecha_inicio)','fields' => 'YEAR(Evento.fecha_inicio) year'));
        $anos = array();
        $i = 0;
        foreach($eventos as $eve)
        {
            $anos[$i] = $eve[0]['year'];
            $i++;
        }
        $this->set(compact('anos'));
    }
    public function cargareportes($ano = null)
    {
        $this->layout = 'ajax';
        $this->set(compact('ano'));
    }
}
?>