<?php
App::uses('AppController', 'Controller');
/**
 * Propietarios Controller
 *
 * @property Propietario $Propietario
 * @property PaginatorComponent $Paginator
 */
class PropietariosController extends AppController {

/**
 * Components
 *
 * @var array
 */
    public $layout = 'kennel';
    var $components = array('RequestHandler','DataTable','Paginator');
    public $uses = array('Propietario','Criadero','Tipo','User');

/**
 * index method
 *
 * @return void
 */
    public function beforeFilter(){
        parent::beforeFilter();
        if($this->RequestHandler->responseType() == 'json'){
            $this->RequestHandler->setContent('json', 'application/json' );
        }
        $this->Auth->allow(array('combo1','combo2','combo3'));
    }
	public function index() {
       
       if($this->RequestHandler->responseType() == 'json') {
            $this->Propietario->virtualFields = array(
                'together' => "CONCAT('".'<a href="#myModal" data-toggle="modal" class="btn-action glyphicons pencil btn-success" id="'."',Propietario.id,'".'"'.' onclick="cargadatos('."', ".''."Propietario.id".''." ,'".')"><i class="icon-pencil"></i></a> <a class="btn btn-danger btn-xs" href="javascript:"'.' onclick="elimina('."', ".''."Propietario.id".''." ,'".')"><i class="icon-trash"></i></a>'."')"
                ,'estadoes' => "SELECT if (estado='1','HABILITADO','DESHABILITADO') FROM propietarios WHERE id=Propietario.id"
            );
            $this->paginate = array(
                'fields' => array('Propietario.id', 'Propietario.nombre', 'Propietario.direccion','Propietario.telefono1','Propietario.estadoes','Propietario.together'),
                'conditions' => array('Propietario.solicitud' => 0),'recursive' => 0,
                'order' => 'Propietario.id ASC'
            );
            $this->DataTable->fields = array('Propietario.id', 'Propietario.nombre', 'Propietario.direccion','Propietario.telefono1','Propietario.estadoes','Propietario.together');
            $this->DataTable->emptyElements = 1;
            $this->set('propietaios', $this->DataTable->getResponse());
            $this->set('_serialize','propietaios');
        }
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Propietario->exists($id)) {
			throw new NotFoundException(__('Invalid propietario'));
		}
		$options = array('conditions' => array('Propietario.' . $this->Propietario->primaryKey => $id));
		$this->set('propietario', $this->Propietario->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add()
    {
        if (!empty($this->request->data))
        {
            $this->Propietario->create();
            //debug($this->request->data);die;
            if ($this->Propietario->save($this->data))
            {
                $this->Session->setFlash('Propietario registrado con exito', 'msgbueno');
                $this->redirect(array('action' => 'index'), null, true);
            } else
            {
                $this->Session->setFlash('No se pudo registrar al Propietario');
            }
        }
    $opt = array('1' => 'Alta', '0' => 'Baja');
    $criaderos = $this->Criadero->find('list', array('fields' => array('Criadero.nombre')));
    $tipos = $this->Tipo->find('list', array('fields' =>'Tipo.nombre'));
    $this->set(compact('opt','criaderos','tipos'));
    }

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null)
    {
        $this->Propietario->id = $id;
        if (!$id)
        {
            $this->Session->setFlash('No existe el Propietario');
            $this->redirect(array('action' => 'index'), null, true);
        }
        if (empty($this->request->data))
        {
            $this->request->data = $this->Propietario->read();
        } else
        {
            if ($this->Propietario->save($this->request->data))
            {
                $this->Session->setFlash('Los datos fueron modificados', 'msgbueno');
                $this->redirect(array('action' => 'index'), null, true);
            } else
            {
                $this->Session->setFlash('no se pudo modificar!!');
            }
        }
    }

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null)
    {
        $this->Propietario->id = $id;
        $this->request->data = $this->Propietario->read();
        if (!$id)
        {
            $this->Session->setFlash('No existe el Propietario a eliminar','msginfo');
            $this->redirect($this->referer());
        } else
        {
            if ($this->Propietario->delete($id))
            {
                $usuario = $this->User->findBypropietario_id($id,null,null,null,null,-1);
                if(!empty($usuario))
                {
                    $this->User->delete($usuario['User']['id']);
                }
                $this->Session->setFlash('Se elimino al Propietario ' . $this->data['Propietario']['nombre'], 'msgbueno');
                $this->redirect($this->referer());
            } else
            {
                $this->Session->setFlash('Error al eliminar','msgerror');
            }
        }
    }
    public function alta($id=null)
    {
        $this->Propietario->id = $id;
        if (!$id) {
            $this->Session->setFlash('No se pudo dar de baja','msgerror');
            $this->redirect($this->referer());
        }
        $estado = 1;
        $this->request->data['Propietario']['estado'] = $estado;

        if ($this->Propietario->save($this->data)) {
            $this->Session->setFlash('Los datos fueron modificados','msgbueno');
            $this->redirect($this->referer());
        } else {
            $this->Session->setFlash('no se pudo modificar!!');
        }
    }
    public function baja($id=null)
    {
        $this->Propietario->id = $id;
        if (!$id) {
            $this->Session->setFlash('No se pudo dar de baja','msgerror');
            $this->redirect($this->referer());
        }
        $estado = 0;
        $this->request->data['Propietario']['estado'] = $estado;

        if ($this->Propietario->save($this->data)) {
            $this->Session->setFlash('Los datos fueron modificados','msgbueno');
            $this->redirect($this->referer());
        } else {
            $this->Session->setFlash('no se pudo modificar!!');
        }
    }
    public function propietario($idPropietario = null)
    {
        $this->Propietario->id = $idPropietario;
        $this->request->data = $this->Propietario->read();
        $this->layout = 'ajax';
        $opt = array('1' => 'Alta', '0' => 'Baja');
        $criaderos = $this->Criadero->find('list', array('fields' => array('Criadero.nombre')));
        $tipos = $this->Tipo->find('list', array('fields' =>'Tipo.nombre'));
        $this->set(compact('opt','criaderos','tipos'));
    }
    public function guardapropietario()
    {
        if(!empty($this->request->data))
        {
            
            $this->Propietario->create();
            //debug($this->request->data['Propietario']);exit;
            if($this->Propietario->save($this->request->data['Propietario']))
            {
                $this->Session->setFlash('Se guardo correctamente!!','msgbueno');
                $this->redirect($this->referer());
            }
            else{
                $this->Session->setFlash('No se guardo!!!','msgerror');
                $this->redirect($this->referer());
            }
        }
        else{
            $this->Session->setFlash('No se guardo!!!','msgerror');
            $this->redirect($this->referer());
        }
    }
    public function pendientes()
    {
        $this->layout = 'ajax';
        $numerop =  $this->Propietario->find('count',array('conditions' => array('Propietario.solicitud' => 1)));
        //debug($numero);exit;
        $this->set(compact('numerop'));
    }
    public function listadopendientes()
    {
        
        $propietarios = $this->Propietario->find('all',array('recursive' => -1,'order' => 'Propietario.id DESC','conditions' => array('Propietario.solicitud' => 1)));
        $this->set(compact('propietarios'));
    }
    public function ajaxlistado()
    {
        $this->layout = 'ajax';
        //debug($this->request->data);exit;
        if (!empty($this->request->data['Propietario']['nombre']) and empty($this->request->data['Propietario']['ci']))
        {
            $propietarios = $this->Propietario->find('all', array('conditions' => array('Propietario.nombre LIKE' => '%'.$this->request->data['Propietario']['nombre'].'%')));
        }
        if (!empty($this->request->data['Propietario']['ci']) and empty($this->request->data['Propietario']['nombre']))
        {
            $propietarios = $this->Propietario->find('all', array('conditions' => array('Propietario.ci LIKE' => '%'.$this->request->data['Propietario']['ci'].'%')));
        }
        if (!empty($this->request->data['Propietario']['ci']) and !empty($this->request->data['Propietario']['nombre']))
        {
            $propietarios = $this->Propietario->find('all', array('conditions' => array('Propietario.ci LIKE' => '%'.$this->request->data['Propietario']['ci'].'%', 'Propietario.nombre LIKE' => '%'.$this->request->data['Propietario']['nombre'].'%')));
        }
        $this->set(compact('propietarios'));
    }
    public function combo1($campoform = null,$div = null)
    {
        $this->layout = 'ajax';
        //debug($campoform);exit;
        $this->set(compact('campoform','div'));
    }
    public function combo2($campoform = null,$div = null)
    {
        $this->layout = 'ajax';
        //debug($this->request->data);exit;
        if(!empty($this->request->data['Propietario']['nombre']))
        {
            $listapropietarios = $this->Propietario->find('all',array('recursive' => -1,
            'conditions' => 
            array('Propietario.nombre LIKE' => '%'.$this->request->data['Propietario']['nombre']."%"),
            'limit' => 8,
            'order' => 'Propietario.nombre ASC'
            ));
        }
        //debug($listamascotas);exit;
        $this->set(compact('listapropietarios','div','campoform'));
    }
    public function combo3($campoform = null,$div = null,$idMascota = null)
    {
        $this->layout = 'ajax';
        $propietario = $this->Propietario->findByid($idMascota,null,null,-1);
        $this->set(compact('campoform','propietario','div'));
    }
    public function aceptar($idPropietario = null)
    {
        $this->Propietario->id = $idPropietario;
        $this->request->data['Propietario']['solicitud'] = 2;
        $this->Propietario->save($this->request->data['Propietario']);
        $this->Session->setFlash('Acepto la solicitud de id '.$idPropietario,'msgbueno');
        $this->redirect($this->referer());
    }
 }
?>