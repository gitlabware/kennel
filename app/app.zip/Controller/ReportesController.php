<?php 
class ReportesController extends AppController{
    public $layout = 'kennel';
    public $uses = array('Sucursale','Ingreso','sucursal');
    public function index()
    {
        $sucursales = $this->Sucursale->find('list',array('fields' => 'Sucursale.nombre'));
        $this->set(compact('sucursales'));
    }
    public function reportepagos()
    {
        $fechaini = $this->request->data['Reporte']['fecha_ini'];
        $fechafin = $this->request->data['Reporte']['fecha_fin'];
        $sucursalid = $this->request->data['Reporte']['sucursale_id'];
        $condiciones = array();
        if(!empty($fechaini) && !empty($fechafin))
        {
            $condiciones['date(Ingreso.created) BETWEEN ? AND ?'] = array($fechaini,$fechafin);
        }
        if(!empty($sucursalid))
        {
            $condiciones['Ingreso.sucursale_id'] = $sucursalid;
        }
        $sucursal = $this->Sucursale->findByid($sucursalid,null,null,null,null,-1);
        $pagos = $this->Ingreso->find('all',array('conditions' => $condiciones));
        //debug($pagos);exit;
        $this->set(compact('pagos','fechaini','fechafin','sucursal'));
    }
}
?>