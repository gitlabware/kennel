<?php
App::uses('AppModel', 'Model');
 
class Examene extends AppModel{
    public $useTable = "examenes";
    
    	
}
?>