<?php
App::uses('AppModel', 'Model');
/**
 * Calificacione Model
 *
 */
class Calificacione extends AppModel {

}
