<?php
App::uses('AppModel', 'Model');
/**
 * Pista Model
 *
 * @property Evento $Evento
 */
class Pista extends AppModel {


	//The Associations below have been created with all possible keys, those that are not needed can be removed

/**
 * hasAndBelongsToMany associations
 *
 * @var array
 */


}
