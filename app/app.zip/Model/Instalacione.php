<?php
App::uses('AppModel', 'Model');
/**
 * Instalacione Model
 *
 */
class Instalacione extends AppModel {

}
